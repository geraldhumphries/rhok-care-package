<?php
/*
 * Copyright 2010 Convio, Inc.
*/
require_once('ConvioOpenAPI.php');

// Base Configuration
$convioAPI = new ConvioOpenAPI;
$convioAPI->host       = 'secure2.convio.net';
$convioAPI->short_name = 'short';
$convioAPI->api_key    = 'aPiKeY';

// Authentication Configuration
$convioAPI->login_name     = 'apiadmin';
$convioAPI->login_password = 'password';

// Choose Format (If not set, a PHP object will be returned)
$convioAPI->response_format = 'xml';

// Set API Parameters
$params = array('cons_id' => 1001021);

// Make API call (ApiServlet_apiMethod)
$response = $convioAPI->call('SRConsAPI_getUser', $params);

print_r($response);
